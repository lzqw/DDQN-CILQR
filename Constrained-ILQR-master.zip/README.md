# Carla-CILQR
Implements a Constrained Iterative LQR controller for an AV in CARLA
